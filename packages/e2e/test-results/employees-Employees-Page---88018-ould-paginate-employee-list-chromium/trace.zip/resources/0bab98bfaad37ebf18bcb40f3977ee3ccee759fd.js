(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/packages_tailwind-config_globals_2a3e0fed.css",
  "static/chunks/_7281a00a._.js",
  "static/chunks/node_modules__pnpm_ad00500e._.js"
],
    source: "dynamic"
});
