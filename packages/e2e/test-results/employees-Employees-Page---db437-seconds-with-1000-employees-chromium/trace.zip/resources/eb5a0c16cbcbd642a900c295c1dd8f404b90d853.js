(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2392ac77._.js",
  "static/chunks/4eca8_next_dist_compiled_6a47fb09._.js",
  "static/chunks/4eca8_next_dist_client_20f11053._.js",
  "static/chunks/4eca8_next_dist_0412da5e._.js",
  "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
],
    source: "entry"
});
