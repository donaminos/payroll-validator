(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_c4b2b12b._.js",
  "static/chunks/dd5cf_lucide-react_dist_esm_icons_ccf674e0._.js"
],
    source: "dynamic"
});
